package com.example.instasnap.model;

import android.net.Uri;

public class InstaImage {
    public Uri getImgResourseUrl() {
        return imgResourseUrl;
    }

    private Uri imgResourseUrl;

    public InstaImage(Uri imgResourseUrl) {
        this.imgResourseUrl = imgResourseUrl;
    }
}

package com.example.instasnap.activities;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toolbar;
import com.example.instasnap.R;
import com.example.instasnap.fragments.FeedActivityFragment;
import com.example.instasnap.fragments.HomeFagments;
import com.example.instasnap.fragments.ProfileFagment;
import com.example.instasnap.fragments.SearchFragment;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.tabs.TabLayout;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

public class MainActivity extends AppCompatActivity
{

    private SectionsPagerAdapter mSectionPagerAdapter;
    private ViewPager mViewPager;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mSectionPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());
        mViewPager = (ViewPager) findViewById(R.id.container);
        mViewPager.setAdapter(mSectionPagerAdapter);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(mViewPager);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setImageDrawable(ContextCompat.getDrawable(getBaseContext(), R.drawable.abc1));

        final Context context = this;
        fab.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
           //     Snackbar.make(view, "Replace with your own action ", Snackbar.LENGTH_LONG)
             //           .setAction("Action", null).show();

                Intent intent = new Intent(context, MediaActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onClickOptionMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionItemSelected(MenuItem item)
    {
        int id=  item.getItemId();
        if(id == R.id.action_setting)
        {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public class SectionsPagerAdapter extends FragmentPagerAdapter
    {
        public SectionsPagerAdapter(FragmentManager fm)
        {
            super(fm);
        }
        @Override
        public Fragment getItem(int position)
        {
            switch()
            {
                case 0:
                    return HomeFagments.newInstance();
                case 1:
                    return SearchFragment.newInstance();
                case 2:
                    return FeedActivityFragment.newInstance();
                case 3:
                    return ProfileFagment.newInstance();
            }

        @Override
        public int getCount()
        {
            return 4;
        }

        @Override
        public CharSequence getPageTitle(int position)
        {
            switch (position)
            {
                case 0:
                    return "HOME";
                case 1:
                    return "SEARCH";
                case 2:
                    return "ACTIVITY";
                case 3:
                return "PROFILE";
            }
            return null;
        }
    }
}